﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint_2.Player
{
    class Bomb : IPlayer
    {
        Texture2D Texture;
        public Bomb(ContentManager Content)
        {
            Texture = Content.Load<Texture2D>("Player/Bomb");
        }
        public void Update()
        {
        }
        public void Draw(SpriteBatch spriteBatch, int x, int y, int direction)
        {
            int width = Texture.Width;
            int height = Texture.Height;

            Rectangle sourceRectangle = new Rectangle(0, 0, width, height);
            Rectangle destinationRectangle = new Rectangle(x, y, width / 10, height / 10);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
