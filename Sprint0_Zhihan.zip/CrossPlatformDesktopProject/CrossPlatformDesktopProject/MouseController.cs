﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0
{
    ///cite from: rbwhitaker.wikidot.com/mouse-input
    public class MouseController:IController
    {
        public Game1 Game { get; set; }
        MouseState oldState = Mouse.GetState();
        public MouseController(Game1 game)
        {
            Game = game;           
        }

        public void Update()
        {
            
            MouseState newState = Mouse.GetState();
            int x = newState.X;
            int y = newState.Y;
            int mid1 = Game.GraphicsDevice.Viewport.Height / 2;
            int mid2 = Game.GraphicsDevice.Viewport.Width / 2;


            if (newState.RightButton == ButtonState.Pressed && oldState.RightButton == ButtonState.Released)
            {
                Game.Exit();
            }
            else if (newState.LeftButton == ButtonState.Pressed && oldState.LeftButton == ButtonState.Released)
            {
                if (x <= mid2 && y <= mid1)
                {
                    Game.sprite = new StandingInPlacePlayerSprite(Game.texture, 1, 12, Game.height, Game.weight);
                }
                else if (x > mid2 && y <= mid1) {
                    Game.sprite = new StandingGifSprite(Game.texture, 1, 12, Game.height,Game.weight);
                }
                else if (x <= mid2 && y > mid1) {
                    Game.sprite = new MoveUpDownSprite(Game.texture, 1, 12, Game.height, Game.weight);
                }
                else if (x > mid2 && y > mid1) {
                    Game.sprite = new LeftRightSprite(Game.texture, 1, 12, Game.height, Game.weight);
                }
            }
            oldState = newState;

        }

    }
}