﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;
using System.Reflection;

namespace Sprint0
{
    /// <summary>
    /// Cite from: rbwhitaker.wikidot.com/monogame-drawing-text-with-spritefonts
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;      
        public List<IController> controllerList; 
        public ISprite sprite { get; set; }
        public int LuigiHeight = 100;
        public int LuigiWidth = 50;
        public Texture2D texture;      
        private SpriteFont font;
        public int height;
        public int weight;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            controllerList = new List<IController>();
            controllerList.Add(new KeyboardController(this));
            controllerList.Add(new MouseController(this));
            IsMouseVisible = true;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            texture = Content.Load<Texture2D>("Luigi");
            font = Content.Load<SpriteFont>("text");
            height = GraphicsDevice.Viewport.Height;
            weight = GraphicsDevice.Viewport.Width;           
            sprite = new StandingInPlacePlayerSprite(texture, 1, 12,height,weight);

        }

        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        protected override void Update(GameTime gameTime)
        {
            foreach (IController controller in controllerList)
            {
                controller.Update();                
                
            }
            sprite.Update();

            base.Update(gameTime);

            
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            spriteBatch.DrawString(font, "Credits:\nProgram Made By: Zhihan Li\nSprites from: www.mariouniverse.com/\nwp-content/img/sprites/nes/smb/luigi.png",
                new Vector2(200, 340), Color.Black);
            spriteBatch.End();
            sprite.Draw(spriteBatch, new Vector2(400,200));
            base.Draw(gameTime);
        }
    }
}
