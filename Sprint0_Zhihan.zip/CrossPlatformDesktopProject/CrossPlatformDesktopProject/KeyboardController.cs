﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Sprint0
{
    ///cite from:  http://rbwhitaker.wikidot.com/basic-keyboard-input
    public class KeyboardController:IController
    {
        public Game1 Game { get; set; }

        public KeyboardController(Game1 game)
        {
            Game = game;

        }
        public void Update()
        {
            KeyboardState keyboardState = Keyboard.GetState();
            ///press 0  to quit, press 1 to display a static character, press 2 to display a animated character, press 3 to move character up and down, press 4 to move character lef and right.
            if (keyboardState.IsKeyDown(Keys.D0)||keyboardState.IsKeyDown(Keys.NumPad0))
            {
                Game.Exit();
            }
            else if (keyboardState.IsKeyDown(Keys.D1)||keyboardState.IsKeyDown(Keys.NumPad1))
            {
                Game.sprite = new StandingInPlacePlayerSprite(Game.texture,1,12, Game.height, Game.weight);               
                
            }
            else if (keyboardState.IsKeyDown(Keys.D2)||keyboardState.IsKeyDown(Keys.NumPad2))
            {
                Game.sprite = new StandingGifSprite(Game.texture, 1, 12, Game.height, Game.weight);
            }
            else if (keyboardState.IsKeyDown(Keys.D3)||keyboardState.IsKeyDown(Keys.NumPad3))
            {
                Game.sprite= new MoveUpDownSprite(Game.texture, 1, 12, Game.height, Game.weight);
            }
            else if (keyboardState.IsKeyDown(Keys.D4)||keyboardState.IsKeyDown(Keys.NumPad4))
            {
                Game.sprite = new LeftRightSprite(Game.texture, 1, 12, Game.height, Game.weight);
            }
           
        }
    }
}

