﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    ///cite from: http://rbwhitaker.wikidot.com/monogame-texture-atlases-3
    public class StandingInPlacePlayerSprite : ISprite
    {
        public Texture2D Texture { get; set; }
        public int Columns { get; set; }
        public int Rows { get; set; }
        private int currentFrame;
        private int totalFrames;

        public StandingInPlacePlayerSprite(Texture2D texture, int rows, int columns, int height, int weight)
        {
            Texture = texture;
            Rows = rows;
            Columns = columns;           
            currentFrame = 0;
            totalFrames = Rows*Columns;
    }
        public void Update()
        {
            //not move Luigi  Initial
        }
        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            int width = Texture.Width / Columns;
            int height = Texture.Height / Rows;
            int row = (int)((float)currentFrame / (float)Columns);
            int column = currentFrame % Columns;

            Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)location.X, (int)location.Y, width, height);
            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }

       
    }
}