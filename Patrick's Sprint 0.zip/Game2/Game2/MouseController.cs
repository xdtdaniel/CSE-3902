﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprite0
{
    class MouseController:IController
    {

        private Game1 game1;

        public MouseController(Game1 game)
        {
            game1 = game;
        }

        public void Update()
        {
            if (Mouse.GetState().RightButton == ButtonState.Pressed)
            {
                game1.Exit();
            }
            if (Mouse.GetState().LeftButton == ButtonState.Pressed && Mouse.GetState().X <= 400 && Mouse.GetState().Y <= 200)
            {
                game1.sprite = new NotMovingNotAnimatedSprite(game1.character, 1, 7);
            }
            if (Mouse.GetState().LeftButton == ButtonState.Pressed && Mouse.GetState().X > 400 && Mouse.GetState().Y <= 200)
            {
                game1.sprite = new NotMovingAnimatedSprite(game1.character, 1, 7);
            }
            if (Mouse.GetState().LeftButton == ButtonState.Pressed && Mouse.GetState().X <= 400 && Mouse.GetState().Y > 200)
            {
                game1.sprite = new MovingNotAnimatedSprite(game1.character, 1, 7);
            }
            if (Mouse.GetState().LeftButton == ButtonState.Pressed && Mouse.GetState().X > 400 && Mouse.GetState().Y > 200)
            {
                game1.sprite = new MovingAnimatedSprite(game1.character, 1, 7);
            }
        }

        

    }
}
