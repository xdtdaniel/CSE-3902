﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprite0
{
    public class textSprite : ISprite
    {
        private SpriteFont font;

        public textSprite(Texture2D texture, int rows, int columns)
        {

        }

        public void Update()
        {
            return;
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
        }
    }
}
