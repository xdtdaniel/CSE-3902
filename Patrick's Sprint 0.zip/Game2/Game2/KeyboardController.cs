﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprite0
{
    class KeyboardController:IController
    {
        private Game1 game1;

        public KeyboardController(Game1 game)
        {
            game1 = game;
        }

        public void Update()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.D0))
            {
                game1.Exit();
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D1))
            {
                game1.sprite = new NotMovingNotAnimatedSprite(game1.character, 1, 7);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D2))
            {
                game1.sprite = new NotMovingAnimatedSprite(game1.character, 1, 7);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D3))
            {
                game1.sprite = new MovingNotAnimatedSprite(game1.character, 1, 7);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D4))
            {
                game1.sprite = new MovingAnimatedSprite(game1.character, 1, 7);
            }

        }

    }

    
}
