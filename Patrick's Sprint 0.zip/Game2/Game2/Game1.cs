﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Security.Cryptography.X509Certificates;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System;

namespace Sprite0
{
    public class Game1 : Game
    {

        List<IController> controllerList; // could also be defined as List <IController>
       public  ISprite sprite;

        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        public Texture2D character;
        public int SpriteX;
        public int SpriteY;
        public SpriteFont font;


        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            controllerList = new List<IController>();
            controllerList.Add(new KeyboardController(this));
            controllerList.Add(new MouseController(this));

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            character = Content.Load<Texture2D>("character3");
            SpriteX = 400;
            SpriteY = 200;
            sprite = new NotMovingNotAnimatedSprite(character,1, 7);
            font = Content.Load<SpriteFont>("CreditFont");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            foreach (IController controller in controllerList)
            {
                controller.Update();
            }

            sprite.Update();

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            Vector2 location = new Vector2();
            location.X = SpriteX;
            location.Y = SpriteY;
            sprite.Draw(_spriteBatch, location);

            _spriteBatch.Begin();
            _spriteBatch.DrawString(font, "Credits\nProgram Made By: Patrick Cheng" +
                "\nSprite from:https://www.mariomayhem.com/downloads/sprites/super_mario_bros_sprites.php ",
                new Vector2(50, 300), Color.Red);
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
