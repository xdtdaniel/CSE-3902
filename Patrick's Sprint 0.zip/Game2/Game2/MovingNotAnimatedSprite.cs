﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Sprite0
{
	public class MovingNotAnimatedSprite : ISprite
	{
		public Texture2D Texture { get; set; }
		public int Rows { get; set; }
		public int Columns { get; set; }
		private int currentFrame;
		private int totalFrames;
		public int SpriteX { get; set; }
		public int SpriteY { get; set; }
		public int i = 0; //flag

		public MovingNotAnimatedSprite(Texture2D texture, int rows, int columns)
		{
			Texture = texture;
			Rows = rows;
			Columns = columns;
			currentFrame = 0;
			totalFrames = Rows * Columns;
			SpriteX = 400;
			SpriteY = 200;
		}

		public void Update()
		{

			if (i == 0)
			{
				SpriteY -= 1;
			}
            if (SpriteY == 0)
            {
				SpriteY = (480 - Texture.Height / Rows);
			}
			/*else
			{
				SpriteY += 1;
			}

			if (SpriteY == 0)
			{
				i = 1;
			}
			else if (SpriteY == (480 - Texture.Height / Rows))
			{
				i = 0;
			}*/
		}

		public void Draw(SpriteBatch spriteBatch, Vector2 location)
		{
			int width = Texture.Width / Columns;
			int height = Texture.Height / Rows;
			int row = (int)((float)currentFrame / (float)Columns);
			int column = currentFrame % Columns;

			Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
			Rectangle destinationRectangle = new Rectangle(SpriteX, SpriteY, width, height);

			spriteBatch.Begin();
			spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
			spriteBatch.End();
		}

	}
}
