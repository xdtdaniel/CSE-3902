﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprite0
{
    public interface IController
    {
        void Update();
    }
}
