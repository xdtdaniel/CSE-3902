﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CrossPlatformDesktopProject
{
    /// <summary>
    /// This is the main type for Sprint0 of CSE3902. Project programed by Jason Lian.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        KeyboardState kOriginalState;
        MouseState mOriginalState;
        IController controller;
        ISprite sprite;
        ISprite textSprite;
        
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
            kOriginalState = Keyboard.GetState();
            mOriginalState = Mouse.GetState();
            controller = new KeyboardController(kOriginalState);
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load the sprite sheet of luigi
            Texture2D texture = Content.Load<Texture2D>("luigi_after_edit_240x16");
            sprite = new SpriteType1(texture, 1, 12, new Vector2(320, 200));
            Texture2D text = Content.Load<Texture2D>("text_sprite");
            textSprite = new TextSprite(text);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (Keyboard.GetState() != kOriginalState) {
                controller = new KeyboardController(kOriginalState);
            } else if (Mouse.GetState() != mOriginalState) {
                controller = new MouseController(mOriginalState);
            }

            controller.UpdateInput();

            if (controller.DisplayType() == 0) {
                Exit();
            } else if (controller.DisplayType() == 1) {
                sprite = new SpriteType1(sprite.GetTexture(), 1, 8, new Vector2(320, 200));
            } else if (controller.DisplayType() == 2) {
                sprite = new SpriteType2(sprite.GetTexture(), 1, 8, new Vector2(320, 200));
            } else if (controller.DisplayType() == 3) {
                sprite = new SpriteType3(sprite.GetTexture(), 1, 8, new Vector2(320, 200));
            } else if (controller.DisplayType() == 4) {
                sprite = new SpriteType4(sprite.GetTexture(), 1, 8, new Vector2(320, 200));
            }

            sprite.Update();

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            sprite.Draw(spriteBatch);
            textSprite.Draw(spriteBatch);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
