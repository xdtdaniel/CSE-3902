﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrossPlatformDesktopProject
{
    public interface IController
    {
        // Update the input state
        void UpdateInput();

        // Return the type of sprite that need to be displayed, or quit the game.
        // 0 for exit, 1 for sprite type 1, 2 for sprite type 2 and so on.
        int DisplayType();
    }
}
