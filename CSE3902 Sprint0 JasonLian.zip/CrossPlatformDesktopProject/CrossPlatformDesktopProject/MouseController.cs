﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CrossPlatformDesktopProject
{
    class MouseController : IController
    {
        public MouseState mState { get; set; }
        public MouseController(MouseState currentState) {
            mState = currentState;
        }
        public void UpdateInput()
        {
            mState = Mouse.GetState();
        }

        public int DisplayType()
        {
            int type = -99;
            if (mState.RightButton == ButtonState.Pressed) {
                type = 0;
            } else if (mState.LeftButton == ButtonState.Pressed) {
                if (mState.X <= 400 && mState.Y <= 240) {
                    type = 1;
                } else if (mState.X > 400 && mState.Y <= 240) {
                    type = 2;
                } else if (mState.X <= 400 && mState.Y > 240) {
                    type = 3;
                } else if (mState.X > 400 && mState.Y > 240) {
                    type = 4;
                }
            }
            return type;
        }
    }
}
