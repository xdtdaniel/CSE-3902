﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace CrossPlatformDesktopProject
{
    public interface ISprite
    {
        // Update the sprite.
        void Update();

        // Draw the sprite on screen.
        void Draw(SpriteBatch spriteBatch);

        // Get the original texture of the sprite.
        Texture2D GetTexture();
    }
}
