﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrossPlatformDesktopProject
{
    class KeyboardController : IController
    {
        public KeyboardState kState { get; set; }
        public KeyboardController(KeyboardState currentState) {
            kState = currentState;
        }
        public void UpdateInput()
        {
            kState = Keyboard.GetState();
        }

        public int DisplayType()
        {
            int type = -99;
            if (kState.IsKeyDown(Keys.D0)) {
                type = 0;
            } else if (kState.IsKeyDown(Keys.D1)) {
                type = 1;
            } else if (kState.IsKeyDown(Keys.D2)) {
                type = 2;
            } else if (kState.IsKeyDown(Keys.D3)) {
                type = 3;
            } else if (kState.IsKeyDown(Keys.D4)) {
                type = 4;
            }
            return type;
        }
    }
}
