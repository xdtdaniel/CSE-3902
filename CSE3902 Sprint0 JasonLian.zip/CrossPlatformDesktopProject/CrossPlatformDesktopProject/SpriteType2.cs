﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace CrossPlatformDesktopProject
{
    class SpriteType2 : ISprite
    {
        public Texture2D Texture { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }
        public Vector2 Location { get; set; }
        private int currentFrame;
        private int totalFrames;
        private int frameRateModifier = 0;

        public SpriteType2(Texture2D texture, int rows, int columns, Vector2 location)
        {
            Texture = texture;
            Rows = rows;
            Columns = columns;
            Location = location;
            currentFrame = 0;
            totalFrames = Rows * Columns;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            int width = Texture.Width / Columns;
            int height = Texture.Height / Rows;
            int row = (int)((float)currentFrame / (float)Columns);
            int column = currentFrame % Columns;

            Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)Location.X, (int)Location.Y, width * 5, height * 5);

            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
        }

        public void Update()
        {
            if (frameRateModifier == 5) {
                currentFrame++;
            }

            frameRateModifier++;

            if (currentFrame == totalFrames / 2) {
                currentFrame = 0;
            }

            if (frameRateModifier > 5) {
                frameRateModifier = 0;
            }
        }

        Texture2D ISprite.GetTexture()
        {
            return Texture;
        }
    }
}
