﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace CrossPlatformDesktopProject
{
    class TextSprite : ISprite
    {
        private Texture2D Texture;

        public TextSprite(Texture2D texture)
        {
            Texture = texture;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture, new Rectangle(0, 0, 800, 480), Color.White);
        }

        public void Update()
        {
            // Do nothing
            throw new NotImplementedException();
        }

        Texture2D ISprite.GetTexture()
        {
            // Do nothing
            throw new NotImplementedException();
        }
    }
}
