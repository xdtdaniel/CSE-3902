﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace CrossPlatformDesktopProject
{
    class SpriteType4 : ISprite
    {
        public Texture2D Texture { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }
        public Vector2 Location { get; set; }
        private int currentFrame;
        private int totalFrames;
        // framRateModifier is used to slow down the update rate of the animated sprite.
        private int frameRateModifier = 0;
        // 0 indictaes moving left, 1 indicates moving right.
        private int movingState = 0;

        public SpriteType4(Texture2D texture, int rows, int columns, Vector2 location)
        {
            Texture = texture;
            Rows = rows;
            Columns = columns;
            Location = location;
            currentFrame = 0;
            totalFrames = Rows * Columns;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            int width = Texture.Width / Columns;
            int height = Texture.Height / Rows;
            int row = (int)((float)currentFrame / (float)Columns);
            int column = currentFrame % Columns;

            Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)Location.X, (int)Location.Y, width * 5, height * 5);

            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
        }

        public void Update()
        {
            float xCoordinate = Location.X;

            if (movingState == 0) {
                if (xCoordinate >= 0 - 7 * 5) {
                    xCoordinate -= 5;
                    Location = new Vector2(xCoordinate, Location.Y);

                    if (frameRateModifier == 5)
                    {
                        currentFrame++;
                    }

                    frameRateModifier++;

                    if (currentFrame == totalFrames / 2)
                    {
                        currentFrame = 0;
                    }

                    if (frameRateModifier > 5)
                    {
                        frameRateModifier = 0;
                    }

                } else {
                    movingState = 1;
                    currentFrame = 4;
                }
            } else if (movingState == 1) {
                if (xCoordinate <= 800 - (Texture.Width / Columns - 7) * 5) {
                    xCoordinate += 5;
                    Location = new Vector2(xCoordinate, Location.Y);

                    if (frameRateModifier == 5)
                    {
                        currentFrame++;
                    }

                    frameRateModifier++;

                    if (currentFrame == totalFrames)
                    {
                        currentFrame = 4;
                    }

                    if (frameRateModifier > 5)
                    {
                        frameRateModifier = 0;
                    }

                } else {
                    movingState = 0;
                    currentFrame = 0;
                }
            }
        }

        Texture2D ISprite.GetTexture()
        {
            return Texture;
        }
    }
}
