﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint_0
{
    class TextSprite: ISprite
    {

        private SpriteFont Font;

        public TextSprite(SpriteFont font)
        {
            Font = font;
        }
        public void Update() 
        { 
        }

        public void Draw(SpriteBatch spriteBatch, ref int x, ref int y, ref bool facingLeft)
        {
            spriteBatch.Begin();

            spriteBatch.DrawString(Font, "Credits\nProgram Made By: Baihua Yang\nSprites from:\nhttps://www.mariomayhem.com/downloads/sprites/smb1/smb_mario_sheet.png", new Vector2(150, 360), Color.Black);

            spriteBatch.End();

        }
    }
}
