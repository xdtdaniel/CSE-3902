﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint_0
{
    class MouseController
    {
        private int key;
        private bool newButtonPressed;
        public MouseController()
        {
            key = 0;
            newButtonPressed = false;
        }
        public void Update()
        {
            MouseState state = Mouse.GetState();
            if (state.LeftButton == ButtonState.Pressed) {
                newButtonPressed = true;
                if (state.X < 400 && state.Y < 240)
                {
                    this.key = 1;
                }
                else if (state.X > 400 && state.Y < 240)
                {
                    this.key = 2;
                }
                else if (state.X < 400 && state.Y > 240)
                {
                    this.key = 3;
                }
                else if (state.X > 400 && state.Y > 240)
                {
                    this.key = 4;
                }
            }
            else
            {
                newButtonPressed = false;
            }

        }
        public int getKey()
        {
            return key;
        }
        public bool newPressed()
        {
            return newButtonPressed;
        }
    }
}
