﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Sprint_0
{
    class KeyboardController: IController
    {
        private int key;
        private bool newButtonPressed;
        public KeyboardController()
        {
            key = 0;
            newButtonPressed = false;
        }
        public void Update()
        {
            KeyboardState state = Keyboard.GetState();
            if (state.IsKeyDown(Keys.D0)) {
                Environment.Exit(0);
            }
            else if (state.IsKeyDown(Keys.D1))
            {
                this.key = 1;
                newButtonPressed = true;
            }
            else if (state.IsKeyDown(Keys.D2))
            {
                this.key = 2;
                newButtonPressed = true;
            }
            else if (state.IsKeyDown(Keys.D3))
            {
                this.key = 3;
                newButtonPressed = true;
            }
            else if (state.IsKeyDown(Keys.D4))
            {
                this.key = 4;
                newButtonPressed = true;
            }
            else
            {
                newButtonPressed = false;
            }

        }

        public int getKey()
        {
            return key;
        }
        public bool newPressed()
        {
            return newButtonPressed;
        }
    }
}
