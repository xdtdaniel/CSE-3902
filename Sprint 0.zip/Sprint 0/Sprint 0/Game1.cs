﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Sprint_0
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        private KeyboardController keyboardController;
        private MouseController mouseController;
        private NonMovingNonAnimatedSprite nonMovingNonAnimatedSprite;
        private NonMovingAnimatedSprite nonMovingAnimatedSprite;
        private MovingNonAnimatedSprite movingNonAnimatedSprite;
        private MovingAnimatedSprite movingAnimatedSprite;
        private TextSprite textSprite;
        private int x;
        private int y;
        private bool facingLeft;
        private int key;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();

            this.IsMouseVisible = true;

            x = graphics.PreferredBackBufferWidth / 2;
            y = graphics.PreferredBackBufferHeight / 2;
            facingLeft = true;
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            keyboardController = new KeyboardController();
            mouseController = new MouseController();

            Texture2D texture = Content.Load<Texture2D>("smb_mario_sheet");
            SpriteFont font = Content.Load<SpriteFont>("Credits");
            nonMovingNonAnimatedSprite = new NonMovingNonAnimatedSprite(texture, 1, 8);
            nonMovingAnimatedSprite = new NonMovingAnimatedSprite(texture, 1, 8);
            movingNonAnimatedSprite = new MovingNonAnimatedSprite(texture, 1, 8);
            movingAnimatedSprite = new MovingAnimatedSprite(texture, 1, 8);
            textSprite = new TextSprite(font);
         

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);

            keyboardController.Update();
            mouseController.Update();

            nonMovingAnimatedSprite.Update();
            movingAnimatedSprite.Update();

        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            base.Draw(gameTime);

            textSprite.Draw(spriteBatch, ref x, ref y, ref facingLeft);

            if (keyboardController.newPressed())
            {
                key = keyboardController.getKey();
            }
            else if (mouseController.newPressed())
            {
                key = mouseController.getKey();
            }
            

            switch (key)
            {
                case 1:
                    nonMovingNonAnimatedSprite.Draw(spriteBatch, ref x, ref y, ref facingLeft);
                    break;
                case 2:
                    nonMovingAnimatedSprite.Draw(spriteBatch, ref x, ref y, ref facingLeft);
                    break;
                case 3:
                    movingNonAnimatedSprite.Draw(spriteBatch, ref x, ref y, ref facingLeft);
                    break;
                case 4:
                    movingAnimatedSprite.Draw(spriteBatch, ref x, ref y, ref facingLeft);
                    break;
                default:
                    break;
            }
        }
    }
}
